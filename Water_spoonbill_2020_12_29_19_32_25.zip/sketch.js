//initiate Game STATEs
var PLAY = 1;
var END = 0;
var gameState = PLAY;

//create a Monkey sprite
var Monkey = createSprite(200,380,20,50);
Monkey.setAnimation("monkey");

//set collision radius for the Monkey
Monkey.setCollider("rectangle",0,0,80,Monkey.height);

//scale and position the Monkey
Monkey.scale = 0.1;
Monkey.x = 50;

//create a ground sprite
var ground = createSprite(200,380,400,20);
ground.setAnimation("ground2");
ground.x = ground.width /2;

//invisible Ground to support Monkey
var invisibleGround = createSprite(200,385,400,5);
invisibleGround.visible = false;

//create Stone and Cloud Groups
var StonesGroup = createGroup();
var CloudsGroup = createGroup();

//set text
textSize(18);
textFont("Georgia");
textStyle(BOLD);

//score
var count = 0;

function draw() {
  //set background to white
  background("white");
  //display score
  text("Score: "+ count, 250, 100);
  console.log(gameState);
  
  if(gameState === PLAY){
    //move the ground
    ground.velocityX = -(6+3*count/100);
    //scoring 
    count = Math.round(World.frameCount/4);
    if (count%100 === 0 && count>0){
     playSound("sound://category_notifications/game_notification_81.mp3");
    }
    if (ground.x < 0){
      ground.x = ground.width/2;
    }
    
     //jump when the space key is pressed
    if(keyDown("space") && Monkey.y >= 300){
      playSound("sound://category_digital/jump_2.mp3");
      Monkey.velocityY = -9 ;
    }
  
    //add gravity
    Monkey.velocityY = Monkey.velocityY + 0.8;
    
    //spawn the clouds
    spawnClouds();
  
    //spawn Stones
    spawnStones();
    
    //End the game when Monkey is touching the Stone
    if(StonesGroup.isTouching(Monkey)){
      playSound("sound://category_poof/puzzle_game_poof_04.mp3");   
      gameState = END;
    }
  }
  
  else if(gameState === END) {
    //set velcity of each game object to 0
    ground.velocityX = 0;
    Monkey.velocityY = 0;
    StonesGroup.setVelocityXEach(0);
    CloudsGroup.setVelocityXEach(0);
    
    //change the Monkey animation
    
    //set lifetime of the game objects so that they are never destroyed
    StonesGroup.setLifetimeEach(-1);
    CloudsGroup.setLifetimeEach(-1);
    
    //place gameOver and restart icon on the screen
    var gameOver = createSprite(200,300);
    var restart = createSprite(200,340);
    
    gameOver.setAnimation("gameOver");
    gameOver.scale = 0.5;
    restart.setAnimation("restart");
    restart.scale = 0.5;
  }
  
  //console.log(Monkey.y);
  
  //stop Monkey from falling down
  Monkey.collide(invisibleGround);
  
  drawSprites();
}

function spawnStones() {
  if(World.frameCount % 60 === 0) {
    var Stone = createSprite(400,365,10,40);
    Stone.velocityX = -(6+count/100);
    
    Stone.setAnimation("Stone");
    
    //assign scale and lifetime to the Stone           
    Stone.scale = 0.2;
    Stone.lifetime = 70;
    //add each Stone to the group
    StonesGroup.add(Stone);
  }
}

function spawnClouds() {
  //write code here to spawn the clouds
  if (World.frameCount % 60 === 0) {
    var cloud = createSprite(400,320,40,10);
    cloud.y = randomNumber(280,320);
    cloud.setAnimation("cloud");
    cloud.scale = 0.5;
    cloud.velocityX = -3;
    
     //assign lifetime to the variable
    cloud.lifetime = 134;
    
    //adjust the depth
    cloud.depth = Monkey.depth;
    Monkey.depth = Monkey.depth + 1;
    
    //add each cloud to the group
    CloudsGroup.add(cloud);
  }
  
}



  
